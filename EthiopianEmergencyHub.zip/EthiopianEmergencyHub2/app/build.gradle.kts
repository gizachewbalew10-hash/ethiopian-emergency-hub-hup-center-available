plugins {
    id("com.android.application")
}

android {
    namespace = "com.gizachew.emergencyhub"
    // የላይብረሪ ስህተቱን ለማስተካከል ወደ 36 ተቀይሯል
    compileSdk = 36

    defaultConfig {
        applicationId = "com.gizachew.emergencyhub"
        minSdk = 24
        targetSdk = 36 // ወደ 36 ተቀይሯል
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {
    // መደበኛ አንድሮይድ ላይብረሪዎች (Hardcoded for stability)
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // ለኔትወርክ (ከ PHP MySQL ጋር ለመገናኘት - Volley)
    implementation("com.android.volley:volley:1.2.1")

    // ለምስል ማሳያ (Glide)
    implementation("com.github.bumptech.glide:glide:4.16.0")
    implementation(libs.activity)

    // ለመሞከሪያ (Testing)
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    implementation("com.android.volley:volley:1.2.1")
    implementation("com.google.android.gms:play-services-location:21.0.1")
}