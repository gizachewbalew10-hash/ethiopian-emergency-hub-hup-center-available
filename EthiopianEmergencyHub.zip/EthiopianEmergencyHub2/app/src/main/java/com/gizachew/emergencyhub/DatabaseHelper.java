package com.gizachew.emergencyhub;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "EmergencyHub.db";
    public static final int DATABASE_VERSION = 3;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE emergency_contacts (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, PHONE TEXT, CATEGORY TEXT)");
        db.execSQL("CREATE TABLE users (ID INTEGER PRIMARY KEY AUTOINCREMENT, PHONE TEXT UNIQUE, PASSWORD TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS emergency_contacts");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    public Cursor getAllData() {
        return getWritableDatabase().rawQuery("SELECT * FROM emergency_contacts", null);
    }

    // searching key)
    public Cursor searchContacts(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        // SQL LIKE query
        return db.rawQuery("SELECT * FROM emergency_contacts WHERE NAME LIKE ?", new String[]{"%" + name + "%"});
    }

    public void addContactFromServer(String name, String phone, String category) {
        ContentValues cv = new ContentValues();
        cv.put("NAME", name);
        cv.put("PHONE", phone);
        cv.put("CATEGORY", category);
        getWritableDatabase().insertWithOnConflict("emergency_contacts", null, cv, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public void saveUserLocally(String phone, String password) {
        ContentValues cv = new ContentValues();
        cv.put("PHONE", phone);
        cv.put("PASSWORD", password);
        getWritableDatabase().insertWithOnConflict("users", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public boolean checkLocalLogin(String phone, String password) {
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM users WHERE PHONE=? AND PASSWORD=?", new String[]{phone, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
}