package com.gizachew.emergencyhub;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    EditText etPhone, etPassword;
    Button btnLogin;
    TextView tvRegister;
    DatabaseHelper myDb;
    String serverIP = "10.139.184.61"; //  IP

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new DatabaseHelper(this);
        etPhone = findViewById(R.id.etPhone);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);

        // Language Switches
        findViewById(R.id.btnEn).setOnClickListener(v -> setAppLocale("en"));
        findViewById(R.id.btnAm).setOnClickListener(v -> setAppLocale("am"));
        findViewById(R.id.btnOm).setOnClickListener(v -> setAppLocale("om"));
        findViewById(R.id.btnTi).setOnClickListener(v -> setAppLocale("ti"));

        tvRegister.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));

        btnLogin.setOnClickListener(v -> {
            String phone = etPhone.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();

            if (phone.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Enter Phone and Password!", Toast.LENGTH_SHORT).show();
            } else {
                if (isOnline()) { performOnlineLogin(phone, pass); }
                else if (myDb.checkLocalLogin(phone, pass)) { goToDashboard(); }
                else { Toast.makeText(this, "Connect to internet once to login!", Toast.LENGTH_LONG).show(); }
            }
        });
    }

    private void performOnlineLogin(String phone, String pass) {
        String url = "http://" + serverIP + "/emergency_api/login.php";
        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    if (response.trim().equals("success")) {
                        myDb.saveUserLocally(phone, pass); // Save for Offline
                        goToDashboard();
                    } else {
                        Toast.makeText(this, "Wrong Credentials on Server", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    if (myDb.checkLocalLogin(phone, pass)) { goToDashboard(); }
                    else { Toast.makeText(this, "Server Error! Check WiFi.", Toast.LENGTH_LONG).show(); }
                }) {
            @Override protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("phone", phone); p.put("password", pass);
                return p;
            }
        };
        Volley.newRequestQueue(this).add(request);
    }

    private boolean isOnline() {
        NetworkInfo ni = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    private void goToDashboard() {
        startActivity(new Intent(this, DashboardActivity.class));
        finish();
    }

    private void setAppLocale(String code) {
        Locale l = new Locale(code); Locale.setDefault(l);
        Configuration c = new Configuration(); c.setLocale(l);
        getResources().updateConfiguration(c, getResources().getDisplayMetrics());
        recreate();
    }
}