package com.gizachew.emergencyhub;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    EditText etName, etPhone, etPass;
    Button btnReg;
    String serverIP = "10.139.184.61";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.etRegName);
        etPhone = findViewById(R.id.etRegPhone);
        etPass = findViewById(R.id.etRegPassword);
        btnReg = findViewById(R.id.btnRegister);

        btnReg.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String pass = etPass.getText().toString().trim();

            if (!name.isEmpty() && !phone.isEmpty() && !pass.isEmpty()) { registerUser(name, phone, pass); }
            else { Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show(); }
        });
    }

    private void registerUser(String n, String ph, String ps) {
        String url = "http://" + serverIP + "/emergency_api/register.php";
        StringRequest req = new StringRequest(Request.Method.POST, url,
                res -> {
                    if(res.trim().equals("success")) {
                        Toast.makeText(this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                        finish();
                    } else if(res.trim().equals("exists")) {
                        Toast.makeText(this, "Phone already registered!", Toast.LENGTH_SHORT).show();
                    } else { Toast.makeText(this, "Error!", Toast.LENGTH_SHORT).show(); }
                },
                err -> Toast.makeText(this, "Server Connection Failed!", Toast.LENGTH_SHORT).show()) {
            @Override protected Map<String, String> getParams() {
                Map<String, String> p = new HashMap<>();
                p.put("name", n); p.put("phone", ph); p.put("password", ps);
                return p;
            }
        };
        Volley.newRequestQueue(this).add(req);
    }
}