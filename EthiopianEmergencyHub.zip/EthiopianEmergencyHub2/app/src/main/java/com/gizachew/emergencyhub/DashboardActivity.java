package com.gizachew.emergencyhub;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {
    DatabaseHelper myDb;
    ListView lv;
    EditText etSearch, etFamily;
    ArrayList<String> list;
    ArrayAdapter<String> adapter;
    String serverIP = "10.139.184.61";
    FusedLocationProviderClient flc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        myDb = new DatabaseHelper(this);
        lv = findViewById(R.id.lvContacts);
        etSearch = findViewById(R.id.etSearch);
        etFamily = findViewById(R.id.etFamilyPhone);
        flc = LocationServices.getFusedLocationProviderClient(this);

        // 1. መፈለጊያው እንዲሰራ የሚያደርግ listener
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ተጠቃሚው በጻፈ ቁጥር መፈለጊያውን ይጥራል
                loadData(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        findViewById(R.id.btnSync).setOnClickListener(v -> sync());
        findViewById(R.id.btnSOS).setOnClickListener(v -> sendSOS());

        loadData("");

        lv.setOnItemClickListener((p, v, pos, id) -> {
            String ph = list.get(pos).split("\n")[1].trim();
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + ph)));
        });
    }

    private void loadData(String q) {
        list = new ArrayList<>();
        Cursor c;
        if (q.isEmpty()) {
            c = myDb.getAllData();
        } else {
            c = myDb.searchContacts(q); // SQL Search መጥራት
        }

        if (c != null) {
            while (c.moveToNext()) {
                list.add(c.getString(1) + "\n" + c.getString(2));
            }
            c.close();
        }
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        lv.setAdapter(adapter);
    }

    private void sync() {
        String url = "http://" + serverIP + "/emergency_api/get_contacts.php";
        JsonArrayRequest req = new JsonArrayRequest(Request.Method.GET, url, null, res -> {
            try {
                for (int i = 0; i < res.length(); i++) {
                    org.json.JSONObject o = res.getJSONObject(i);
                    myDb.addContactFromServer(o.getString("name"), o.getString("phone"), o.getString("category"));
                }
                loadData(""); // Sync ሲያልቅ refresh ማድረግ
                Toast.makeText(this, "Sync Successful!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { e.printStackTrace(); }
        }, err -> Toast.makeText(this, "Sync Failed!", Toast.LENGTH_SHORT).show());
        Volley.newRequestQueue(this).add(req);
    }

    private void sendSOS() {
        String famPh = etFamily.getText().toString().trim();
        if(famPh.isEmpty()){ Toast.makeText(this, "Enter Family Number!", Toast.LENGTH_SHORT).show(); return; }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.SEND_SMS}, 1);
            return;
        }
        flc.getLastLocation().addOnSuccessListener(loc -> {
            if (loc != null) {
                String msg = "SOS! Help me. Location: https://maps.google.com/maps?q=" + loc.getLatitude() + "," + loc.getLongitude();
                SmsManager.getDefault().sendTextMessage(famPh, null, msg, null, null);
                Toast.makeText(this, "SOS Message Sent!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}